# Kinlove Kitchen inventory

Offline-first kitchen inventory PWA.

Features:
- Pastel pink/yellow design
- User-supplied Kitchen Inventory logo
- iPhone/Android home-screen icon assets
- Offline storage on each device
- Date/time on every quantity update
- Locked inventory mode to prevent accidental changes
- Unlock to edit, then lock again
- Add/delete items
- Notes for Condiments & Seasoning
- No home-screen instructions inside the app
