# Kinlove Inventory

GitHub Pages-ready offline inventory PWA for Kinlove.

## Included
- FOH Inventory and Kitchen Inventory
- All items supplied in the project brief
- Add/delete custom items
- Quantity editing, reset, undo
- Finalize/lock state
- Password protection using local SHA-256 hash
- Date/time on saved updates
- Notes only for Condiments
- Kinlove logo and iPhone/Android app icons
- Offline caching through a service worker

## Important password-recovery note
A completely offline static app cannot securely send an email by itself. The UI includes the recovery-email field and recovery flow, but actual email reset requires connecting an email/authentication service (for example Firebase Authentication or EmailJS) and its project credentials. Inventory itself remains locally available offline.

## GitHub Pages
Upload the contents of this folder to a GitHub repository and enable GitHub Pages for the branch/folder containing `index.html`.

The first visit requires internet once so the service worker can cache the app. After that, normal inventory use works offline.
